from windows import winproxy
import windows.generated_def as gdef
import windows.crypto

